document.addEventListener('DOMContentLoaded', function() {
    const qrInput = document.getElementById('qrInput');
    const genrateBtn = document.getElementById('genrateBtn');
    const qrpopup = document.getElementById('qrpopup');
    const qrImage = qrpopup.querySelector('img');
    const downlodBtn = document.getElementById('downlodBtn');
    const closeBtn = document.getElementById('closeBtn');

    genrateBtn.addEventListener('click', function() {
        const inputValue = qrInput.value;
        const qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(inputValue);
        qrImage.src = qrCodeUrl;
        qrpopup.style.display = 'block';
    });

    downlodBtn.addEventListener('click', function() {
        const qrImageUrl = qrImage.src;
        const a = document.createElement('a');
        a.href = qrImageUrl;
        a.download = 'qr-code.png';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });

    closeBtn.addEventListener('click', function() {
        qrpopup.style.display = 'none';
    });
});
